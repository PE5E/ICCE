#!/bin/bash

g++ *.cc *.ih -o main --std=c++17 -Werror -Wall
./main -d < input.txt >> output.txt
./main -e < output.txt >> return.txt

echo "INPUT=============="
cat input.txt
echo "OUTPUT============="
cat output.txt
echo "INPUT?============="
cat return.txt

