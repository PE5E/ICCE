void usage(string const &programName)
{
    char const use[]=
    R"(
        blabla
        )";
    std::cout << use << "\n";
}
