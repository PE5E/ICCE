// ln2.cc 
#include <math.h>

double const ln2 = log(2);

// this file is required for the global const ln2
