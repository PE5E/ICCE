// method5.cc
#include "myheader.h"
#include <iostream>
#include <math.h>

using namespace std;


void method5(unsigned long long int const valueToAnalyze, int nrOfTurns)
{

    while (nrOfTurns != 0)
    {
        // doing nothing as many times as you ask
        --nrOfTurns;
    }

    cout << "Method 5 logarithm.\n";
    cout << "I don't think it is possible to calculate the LSbit with " 
        << "logarithm \n";

    return;
}
