#include "cpu.ih"
#include <iosfwd>

Cpu::Cpu(Memory const &memory1)
//:
{
    d_memory = memory1;
}
