#include "cpu.ih"

bool Cpu::err()
// 

{
    cout << "syntax error /n";
    return false;
}
