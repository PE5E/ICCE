#include "memory.ih"

Memory::Memory()
{
}

