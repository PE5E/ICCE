#include "demo.ih"

demo::demo()
{
    cout << '\t' << __FILE__ << ": constructor called" << '\n';
}
