#include "demo.ih"

demo::~demo()
{
    cout << '\t' << __FILE__ << ": destructor called" << '\n';
}
