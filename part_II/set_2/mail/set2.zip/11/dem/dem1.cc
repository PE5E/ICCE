#include "dem.ih"

Dem::Dem()
//:
{
    std::cerr << "\t Calling default constructor " << '\n';
}
