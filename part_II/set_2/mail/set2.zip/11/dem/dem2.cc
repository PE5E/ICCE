#include "dem.ih"

Dem::Dem(Dem const &other)
//:
{
    std::cerr << "\t Calling copy constructor" << '\n';
}
