#ifndef MAXFOUR_H
#define MAXFOUR_H

#include <cstddef>

class MaxFour
{
    inline static size_t s_count = 0;

    public:
        MaxFour();      // constructor
        ~MaxFour();     // destructor
    private:
};

#endif
