#include "addition.ih"

Addition::Addition()
{}
