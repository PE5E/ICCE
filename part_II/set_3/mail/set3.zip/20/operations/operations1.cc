#include "operations.ih"

Operations::Operations()
//:
{
}
