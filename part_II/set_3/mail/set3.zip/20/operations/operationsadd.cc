#include "operations.ih"

void Operations::add(Operations const &rhs)
{
    cerr << __FILE__ << ": Operations::add was called" << '\n';
    return; 
}
