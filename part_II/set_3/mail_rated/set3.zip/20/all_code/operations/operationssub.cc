#include "operations.ih"

void Operations::sub(Operations const &rhs)
{
    cout << __FILE__ << ": Operations::sub was called" << '\n';
    return; 
}
