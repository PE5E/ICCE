#include "subtraction.ih"

Subtraction::Subtraction()
{}
