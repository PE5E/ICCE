#include "main.ih"

void usage()
{
	cout << "This is a very simple calculator, please" << '\n'
	     << "only specify '-', '-=', '+', '+=', or 'stop'." << '\n';

	return;
}