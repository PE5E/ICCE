#include "ifdstreambuf.ih"

void IFdStreambuf::close()
{
    clean();
}
