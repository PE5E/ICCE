#include "ofdstreambuf.ih"

void OFdStreambuf::close()
{
    clean();
}
