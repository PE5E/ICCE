namespace FBB
{
    thread_local int g_errno;
}
