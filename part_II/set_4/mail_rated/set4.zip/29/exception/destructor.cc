#include "exception.ih"

Exception::~Exception() noexcept(true)
{}
