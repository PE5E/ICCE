#include "main.ih"

int main()
{
	printOrderedInput();
}