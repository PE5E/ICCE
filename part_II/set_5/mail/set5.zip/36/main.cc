#include "main.ih"

int main()
{
	countAndPrintOrderedInput();
}