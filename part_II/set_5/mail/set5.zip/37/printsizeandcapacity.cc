#include "main.ih"

void printSizeAndCapacity(vector<string> const &strVector)
{
	cout << "size:     " << strVector.size()     << '\n'
	     << "capacity: " << strVector.capacity() << '\n';
} 
