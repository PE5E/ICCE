#include "stringvector.ih"

StringVector::StringVector(ifstream &inputFile)
{
	fileIntoVector(inputFile);
}