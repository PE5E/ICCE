#include "storage.ih"

Storage::Storage()
//:
{
}
