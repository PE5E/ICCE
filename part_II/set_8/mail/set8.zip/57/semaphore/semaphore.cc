#include "semaphore.ih"

Semaphore::Semaphore(size_t nAvailable)
    :
        d_nAvailable(nAvailable)
{}
