#ifndef INCLUDED_MAIN_
#define INCLUDED_MAIN_

#include <future>
#include <algorithm>
#include <iostream>

using namespace std;

void quicksort(int *beg, int *end);

#endif