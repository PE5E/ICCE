#ifndef ADD_HH
#define ADD_HH

#include "main.ih"

template <typename Type>
Type add(Type const &lhs, Type const &rhs)
{
    return lhs + rhs;
}

#endif // ADD_HH
