#include "doublevalue.ih"

DoubleValue::DoubleValue(double value)
:
    d_value(value)
{
}
