#include "intvalue.ih"

IntValue::IntValue(int value)
:
    d_value(value)
{
}
