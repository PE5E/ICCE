#include "main.ih"

int main()
{
    DoubleValue doubleVal{ 3.0 };
    cout << doubleVal << '\n';

    IntValue intVal{ 6 };
    cout << intVal << '\n';
}
