#include "main.ih" 

int main()
{
    cout << Bin<5>::value   << '\n' <<
            Bin<27>::value  << '\n' <<
            Bin<12>::value  << '\n' <<
            Bin<210>::value << '\n' <<
            Bin<33>::value  << '\n';
}
