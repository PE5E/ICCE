#include "adder.ih"

std::string const &Adder::value() const;
{
    return d_value;
}
