#include "data.ih"
Data::Data(std::vector<std::string> &initial)
:
    d_data(initial)
{
}
