#ifndef INCLUDED_CALCULATOR_
#define INCLUDED_CALCULATOR_

#include <string>

#include "../scanner/scanner.h"
#include "../expr/expr.h"
#include "../symtab/symtab.h"

class Value;
class Command;

namespace FBB
{
    class ReadLineStream;
}

class Calculator
{
    static FBB::ReadLineStream s_in;

    Scanner d_scanner;
    Symtab d_symtab;
    Expr d_expr;
    size_t d_displayRadix = 10;

    public:
        Calculator();

        void evaluate();

    private:
        void display(Value const &value);
        void displayInt(long long value) const;
        bool handle(Command const &command);
};
        
#endif





