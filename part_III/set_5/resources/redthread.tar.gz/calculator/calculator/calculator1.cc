#include "calculator.ih"

Calculator::Calculator()
:
    d_scanner(s_in),
    d_expr(d_scanner, d_symtab)
{}
