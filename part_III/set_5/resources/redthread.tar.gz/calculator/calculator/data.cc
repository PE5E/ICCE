#include "calculator.ih"

ReadLineStream Calculator::s_in("? ", 20,  ReadLineBuf::EXPAND_HISTORY);


