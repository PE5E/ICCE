#include "calculator.ih"

void Calculator::display(Value const &ret)
{
    if (d_scanner.token() != '\n')
        throw Exception() << "improper end of expression or command";

    if (not (ret.derefType() == Value::INT && d_displayRadix != 10))
        cout << "  " << ret << '\n';
    else
    {
        displayInt(ret.longint());
        cout << '\n';
    }
}
