#include "calculator.ih"

void Calculator::evaluate()
{
    Command command(d_scanner);

    cout << "Navcalc ready.\n"
            "Enter /help to see what you can do\n";

    while (true)                    // we continuously read info from lines
    {
        try
        {
            switch (command.type())
            {
                case Command::QUIT:
                    if (d_scanner.lex() == 0)
                        cout << '\n';
                    cout << "Bye\n";
                return;
    
                case Command::COMMAND:
                    if (not handle(command))
                        return;
    
                default:
                break;
            
                case Command::EXPRESSION:
                    display(d_expr.eval()); // display the next expression's
                                            // value
                break;
            }
        }
        catch (exception const &exc)
        {
            cout << exc.what() << '\n';
            d_scanner.startINITIAL();
        }
    }
}


