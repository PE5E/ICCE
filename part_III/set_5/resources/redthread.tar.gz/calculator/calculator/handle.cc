#include "calculator.ih"

bool Calculator::handle(Command const &command)
{
    Data data(d_scanner, d_symtab);

    string const &cmd = d_scanner.matched().substr(1);

    switch (command.handle(cmd))
    {
        case Command::QUIT:
            cout << "Bye\n";
        return false;

        case Command::LIST:
            d_symtab.list();
        break;

        case Command::READ:
            data.read();
        break;

        case Command::WRITE:
            data.write();
        break;

        case Command::RAD:
            Value::setAngleType(Value::AngleType::RAD);
        break;

        case Command::DEG:
            Value::setAngleType(Value::AngleType::DEG);
        break;

        case Command::GRAD:
            Value::setAngleType(Value::AngleType::GRAD);
        break;

        case Command::DISPLAYRADIX:
            d_displayRadix = stoul(cmd);
            Value::verifyRadix(d_displayRadix);                                    
        break;

        default:
        break;
    }

    return true;
}



