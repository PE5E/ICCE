#ifndef INCLUDED_COMMAND_
#define INCLUDED_COMMAND_

#include <iosfwd>

class Scanner;

class Command
{
    Scanner &d_scanner;

    public:
        enum Handling
        {
            QUIT,
            CONTINUE,
            COMMAND,
            EXPRESSION,
            READ,
            WRITE,
            LIST,
            DEG,
            RAD,
            GRAD,
            DISPLAYRADIX,
        };

        explicit Command(Scanner &tokenizer);        
        Handling type() const;
        Handling handle(std::string const &cmd) const;

    private:
        void help() const;
};
        
#endif



