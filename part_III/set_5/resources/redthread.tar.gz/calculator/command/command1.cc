#include "command.ih"

Command::Command(Scanner &scanner)
:
    d_scanner(scanner)
{}
