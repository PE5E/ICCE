#include "command.ih"


Command::Handling Command::handle(std::string const &cmd) const
{
    if (string("help").find(cmd) == 0)
    {
        help();
        return CONTINUE;
    }

    if (string("quit").find(cmd) == 0)
        return QUIT;

    if (string("list").find(cmd) == 0)
        return LIST;

    if (string("read").find(cmd) == 0)
        return READ;

    if (string("rad").find(cmd) == 0)
        return RAD;

    if (string("grad").find(cmd) == 0)
        return GRAD;

    if (string("deg").find(cmd) == 0)
        return DEG;

    if (string("write").find(cmd) == 0)
        return WRITE;

    if (isdigit(cmd[0]))
        return DISPLAYRADIX;

    throw Exception() << "Command `" << cmd << "' not implemented\n";
    return CONTINUE;
}






