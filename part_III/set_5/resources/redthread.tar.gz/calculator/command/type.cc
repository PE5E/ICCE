#include "command.ih"

Command::Handling Command::type() const
{
    switch (d_scanner.lex())
    {
        case 0:
        return QUIT;

        case '\n':
        return CONTINUE;

        case Token::COMMAND:
        return COMMAND;

        default:
        return EXPRESSION;
    }
}
