#ifndef INCLUDED_DATA_
#define INCLUDED_DATA_

#include <iosfwd>

#include "../value/value.h"

class Scanner;
class Symtab;

class Data
{
    Scanner &d_scanner;
    Symtab &d_symtab;

    public:
        Data(Scanner &scanner, Symtab &symtab);
        ~Data();

        void read() const;
        void write() const;

    private:
        std::string filename() const;
        void read(std::string const &name, bool clearSymtab = false) const;
        void write(std::string const &name) const;

        void add(std::string const &line) const;
        std::string getName(std::istringstream &in) const;
        Value::Type getType(std::istringstream &in) const;
        Value getValue(std::istringstream &in,
                       Value::Type type, double firstValue) const;

        std::string defaultName() const;
};
        
#endif
