#include "data.ih"

Data::Data(Scanner &scanner, Symtab &symtab)
:
    d_scanner(scanner),
    d_symtab(symtab)
{
    string name;
    if (Arg::instance().option(&name, 'r'))
    {
        if (name.empty())
            name = defaultName();
        read(name);
    }
}
