#include "data.ih"

string Data::defaultName() const
{
    string name(getenv("HOME"));
    name += "/.navrc";

    return name;
}
