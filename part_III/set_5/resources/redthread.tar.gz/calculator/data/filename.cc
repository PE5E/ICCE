#include "data.ih"

string Data::filename() const
{
    string name = d_scanner.token() == Token::IDENTIFIER ?
        d_scanner.matched()
    :
        defaultName();

    d_scanner.startINITIAL();

    return name;
}
