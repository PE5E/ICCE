#include "data.ih"

Value Data::getValue(istringstream &in, 
                     Value::Type type, double firstValue) const
{
    Value ret;

    if (type != Value::FIX)
        ret = Value::factory(type, firstValue);
    else
    {
        double longitude;
        if (not (in >> longitude))     // err if longitude is missing
            throw Exception() << "longitude of FIX value missing";

        ret = Value::factory(firstValue, longitude);
    }

    return ret;
}
