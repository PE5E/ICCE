#include "data.ih"

void Data::read() const
{
    bool clearSymtab = true;

    d_scanner.startData();

    if (d_scanner.lex() == Token::PLUS_IS)
    {
        clearSymtab = false;
        d_scanner.lex();
    }

    string name = filename();

    read(filename(), clearSymtab);
}

