#include "data.ih"

void Data::read(string const &name, bool clearSymtab) const
{
    ifstream in(name);

    if (!in)
        throw Exception() << "Can't read `" << name << "'";

    if (clearSymtab)
        d_symtab.clear();

    string line;
    while (getline(in, line))
        add(line);        
}
