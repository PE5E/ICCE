#include "data.ih"

void Data::write() const
{
    d_scanner.startData();

    d_scanner.lex();

    write(filename());
}








