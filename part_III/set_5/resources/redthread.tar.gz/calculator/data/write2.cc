#include "data.ih"

void Data::write(std::string const &name) const
{
    ofstream out(name);

    if (!out)
        throw Exception() << "Can't write `" << name << "'";

    for (auto &entry: d_symtab)
        cout << entry << '\n';
}








