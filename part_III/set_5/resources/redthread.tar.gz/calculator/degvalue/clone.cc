#include "degvalue.ih"

ValueBase *DegValue::clone() const
{
    return new DegValue(value());
}
