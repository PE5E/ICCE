#include "degvalue.ih"

DegValue::DegValue(double value)
:
    DoubleBase(DEG, value)
{}
