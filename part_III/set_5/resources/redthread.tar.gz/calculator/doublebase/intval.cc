#include "doublebase.ih"

long long DoubleBase::intVal() const
{
    return d_value;
}
