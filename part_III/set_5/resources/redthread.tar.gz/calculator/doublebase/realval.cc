#include "doublebase.ih"

double DoubleBase::realVal() const
{
    return d_value;
}
