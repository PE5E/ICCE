#include "doublebase.ih"

double DoubleBase::value() const
{
    return d_value;
}
