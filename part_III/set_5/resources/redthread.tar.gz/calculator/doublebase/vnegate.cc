#include "doublebase.ih"

void DoubleBase::vNegate()
{
    d_value = -d_value;
}
