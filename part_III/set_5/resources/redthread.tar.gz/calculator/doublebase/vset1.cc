#include "doublebase.ih"

void DoubleBase::vSet(Type, long long value)
{
    d_value = value;
}
