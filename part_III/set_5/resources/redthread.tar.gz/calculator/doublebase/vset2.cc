#include "doublebase.ih"

void DoubleBase::vSet(Type type, double value)
{
    d_value = normalize(type, value);
}
