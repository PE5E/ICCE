#ifndef INCLUDED_EXCEPTION_
#define INCLUDED_EXCEPTION_

#include <sstream>
#include <exception>

    // This class acts like an ostringstream and is an exception:
class Exception: public std::exception
{
    template <typename Type>
    friend Exception &&operator<<(Exception &&in, Type const &value);
        
    std::ostringstream d_os;

    public:
        Exception() = default;
        Exception(Exception const &other);  // need to define, since no CC
                                            // exists for ios.
          // need to define with noexcept(true) as the base class does so:
        ~Exception() noexcept(true) override;

    private:
        char const *what() const noexcept(true) override;   
};

template <typename Type>
Exception &&operator<<(Exception &&in, Type const &value)
{
    in.d_os << value;
    return std::move(in);
}
        
#endif




