#include "exception.ih"

Exception::Exception(Exception const &other)
:
    d_os(other.d_os.str())
{}

