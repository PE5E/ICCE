#include "exception.ih"

char const *Exception::what() const noexcept(true)
{
    return d_os.str().c_str();
}
