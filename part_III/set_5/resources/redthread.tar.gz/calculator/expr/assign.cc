#include "expr.ih"

Value Expr::assign()
{
    Value ret(shift());          // obtain the next expression

    while (true)                // maybe '=' tokens follow
    {        
                                // use a switch to allow future extensions
                                // using += etc.
        switch (d_scanner.token()) // see if the next token is available   
        {
            case '=':
                if (not ret.isLvalue())
                    throw Exception() << "missing lvalue in assignment";

                d_scanner.lex(); // prepare the next token
                ret.assign(assign());
            continue;
                // right associative operator: the rhs
                // must first be evaluated using recursion

            default:            // return `ret' in all other cases
            break;
        }
        break;
    }

    return ret;
}




