#include "expr.ih"

Value Expr::eval()
{
    d_typeCast = false;
    return assign();
}
