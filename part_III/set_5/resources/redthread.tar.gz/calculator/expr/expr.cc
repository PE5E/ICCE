#include "expr.ih"

Value Expr::expr()
{
    Value ret(term());           // obtain the next term

    while (true)                // maybe '+' or '-' tokens follow
    {        
        switch (d_scanner.token()) // see if the next token is available   
        {
            case '+':
                d_scanner.lex(); // prepare the next token
                ret += term();
            continue;

            case '-':
                d_scanner.lex(); // prepare the next token
                ret -= term();
            continue;

            default:            // return `ret' in all other cases
            break;
        }
        break;
    }
    return ret;
}


