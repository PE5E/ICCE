#ifndef INCLUDED_EXPR_
#define INCLUDED_EXPR_

#include <iosfwd>

class Scanner;
class Value;
class Symtab;

class Expr
{
    Scanner &d_scanner;
    Symtab &d_symtab;
    bool d_typeCast = false;
    
        // since there are no modifiable data members, all member functions
        // can be const

    public:
        Expr(Scanner &scanner, Symtab &d_symtab);

        Value eval();                   // top-level function encapsulating
                                        // the expression evaluation, se
                                        // additional levels of evaluation can
                                        // easily be implemented
    private:
        Value typeCast();

        Value assign();
        Value shift();
        Value expr();
        Value term();
        Value factor();

        Value identifier();
        Value functionCall(std::string const &name);
};
        
#endif





