#include "expr.ih"

Expr::Expr(Scanner &scanner, Symtab &symtab)
:
    d_scanner(scanner),
    d_symtab(symtab)
{}
