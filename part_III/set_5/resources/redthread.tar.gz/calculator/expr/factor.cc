#include "expr.ih"

Value Expr::factor()
{
    Value ret;

    switch (d_scanner.token())         // see if the next token is
    {                                   // available   
        case Token::TYPE:
            ret = typeCast();
            d_scanner.lex();
        break;

        case Token::IDENTIFIER:
            ret = identifier();         // does 'next' after obtaining the id
        break;

        case Token::VALUE:
            ret = d_scanner.value();

            d_scanner.lex();         // prepare the next token
        break;

        case '-':
            d_scanner.lex();         // prepare the next token
            ret = -factor();
        break;

        case '(':
            d_scanner.lex();         // prepare the next token
            ret = expr();
            if (d_scanner.token() != ')')
                throw Exception() << "closing parenthesis missing";
            d_scanner.lex();

            if (d_typeCast)
            {
                d_typeCast = false;
                ret = factor().cast(ret.type());
            }
        break;

        default:
        throw Exception() << "syntax error in expression factor";
    }

    return ret;
}




