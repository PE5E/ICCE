#include "expr.ih"

// When a function is called, it is handled by Symtab's operator()
// (operatorfun.cc) This function passes name, number of arguments and
// arguments to Function's operator() (operatorfun.cc) 
//
// Function's operator() looks up the function name in s_function. If found it
// calls the function whose address is stored in the map's second value. This
// address points to an object of a class derived from FunBase.
//
// Classes are derived by Function::makeHandler, instantiating a Handler class
// template (which is a nested class of Function itself). 

// The Handler's constructor receives as its 3rd argument a convertor
// function. The convertor function calls the function specified as the
// Handler's 4th argument, which is (if available) an existing function
// performing the required computation. The convertor takes care of the proper
// conversion of actual arguments (in Value objects) to arguments
// required/expected by the function.

// The Handler class template's type argument defines the `Value creator'
// class. E.g., FixValue. FixValue's constructor receives its arguments from
// the fixConvertor function, passed to makeHandler. So: 
// convertor -> calls a constructor of a class derived from Value to create 
// the appropriate value type.

// If arguments require special handling, then the convertor should be
// responsible for that.



    // the openparen is the current peek-value
Value Expr::functionCall(std::string const &name)
{
    d_scanner.lex();

    Value ret;

    vector<Value> args;

    while (true)
    {
        switch (d_scanner.token())
        {
            case ',':
                d_scanner.lex();
            continue;

            case ')':
                d_scanner.lex();                
                ret = d_symtab(name, args.size(), &args[0]);
                if 
                (
                    ret.type() == Value::RAD && 
                    Value::angleType() != Value::RAD
                )
                    ret = Value::factory(
                                Value::angleType(), 
                                Value::circleConversion(Value::RAD,
                                                        Value::angleType(), 
                                                        ret.real())
                            );
            break;

            default:
                args.push_back(expr());
            continue;
        }
        break;
    }

    return ret;
}



