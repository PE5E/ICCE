#include "expr.ih"

Value Expr::identifier()
{
    string ident = d_scanner.matched();         // get the identifier

    Value ret = d_scanner.lex() == '(' ?        // a function call ?
                    functionCall(ident)         // then handle the call + args
                :                               // or obtain a variable
                    Value(new IdentValue(d_symtab[ident]));

    return ret;
}






