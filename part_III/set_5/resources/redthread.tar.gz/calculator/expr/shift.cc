#include "expr.ih"

Value Expr::shift()
{
    Value ret(expr());           // obtain the next term

    while (true)                // maybe '+' or '-' tokens follow
    {        
        switch (d_scanner.token()) // see if the next token is available   
        {
            case Token::LSHIFT:
                d_scanner.lex(); // prepare the next token
                ret <<= expr();
            continue;

            case Token::RSHIFT:
                d_scanner.lex(); // prepare the next token
                ret >>= expr();
            continue;

            default:            // return `ret' in all other cases
            break;
        }
        break;
    }
    return ret;
}


