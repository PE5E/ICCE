#include "expr.ih"

Value Expr::term() 
{
    Value ret(factor());        // obtain the next factor

    while (true)                // maybe '*', '/' or '%' tokens follow
    {        
        switch (d_scanner.token())    // see if the next token is
        {                                   // available   
            case '*':
                d_scanner.lex();        // prepare the next token
                ret *= factor();
            continue;
            break;

            case '/':
                d_scanner.lex();        // prepare the next token
                ret /= factor();
            continue;

            case '%':
                d_scanner.lex();        // prepare the next token
                ret %= factor();
            continue;

            default:            // return `ret' in all other cases
            return ret;
        }
        break;
    }

    return ret;
}

