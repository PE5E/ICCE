#include "expr.ih"

Value Expr::typeCast()
{
    Value ret(Value::factory(Value::type(d_scanner.matched()), 0));
    d_typeCast = true;
    return ret;
}
