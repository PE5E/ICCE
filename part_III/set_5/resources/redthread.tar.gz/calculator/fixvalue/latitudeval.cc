#include "fixvalue.ih"

double FixValue::latitudeVal() const
{
    return d_latitude;
}
