#include "fixvalue.ih"

double FixValue::longitudeVal() const
{
    return d_longitude;
}
