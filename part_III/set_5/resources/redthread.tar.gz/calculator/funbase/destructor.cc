#include "funbase.ih"

FunBase::~FunBase()
{}
