#include "funwrap.ih"

FunWrap::FunWrap(FunBase *funBase)
:
    d_base(funBase)
{}
