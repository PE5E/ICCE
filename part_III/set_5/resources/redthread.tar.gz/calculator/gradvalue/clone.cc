#include "gradvalue.ih"

ValueBase *GradValue::clone() const
{
    return new GradValue(value());
}
