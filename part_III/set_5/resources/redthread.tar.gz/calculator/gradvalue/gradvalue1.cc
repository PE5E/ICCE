#include "gradvalue.ih"

GradValue::GradValue(double value)
:
    DoubleBase(GRAD, value)
{}
