#include "identvalue.ih"

ValueBase *IdentValue::clone() const
{
    return d_value->valueBase().copy();
}
