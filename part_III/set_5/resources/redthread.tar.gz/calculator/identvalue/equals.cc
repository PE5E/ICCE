#include "identvalue.ih"

bool IdentValue::equals(ValueBase const &rhs) const
{
    return d_value->valueBase() == rhs;
}
