#include "identvalue.ih"

IdentValue::IdentValue(Value &value)
:
    ValueBase(IDENT),
    d_value(&value)
{}
