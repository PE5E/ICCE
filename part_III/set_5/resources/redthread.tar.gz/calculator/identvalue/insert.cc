#include "identvalue.ih"

std::ostream &IdentValue::insert(std::ostream &out) const
{
    return out << *d_value;
}
