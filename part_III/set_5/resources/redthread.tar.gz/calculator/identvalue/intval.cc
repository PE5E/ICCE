#include "identvalue.ih"

long long IdentValue::intVal() const
{
    return d_value->longint();
}
