#include "identvalue.ih"

double IdentValue::latitudeVal() const
{
    return d_value->latitude();
}
