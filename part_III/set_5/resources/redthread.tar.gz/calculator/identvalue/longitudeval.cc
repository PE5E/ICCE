#include "identvalue.ih"

double IdentValue::longitudeVal() const
{
    return d_value->longitude();
}
