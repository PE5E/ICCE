#include "identvalue.ih"

double IdentValue::realVal() const
{
    return d_value->real();
}
