#include "intvalue.ih"

ValueBase *IntValue::clone() const
{
    return new IntValue(d_value);
}
