#include "intvalue.ih"

ostream &IntValue::insert(ostream &out) const
{
    return out << d_value;
}
