#include "intvalue.ih"

long long IntValue::intVal() const
{
    return d_value;
}
