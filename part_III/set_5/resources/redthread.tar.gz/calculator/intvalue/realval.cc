#include "intvalue.ih"

double IntValue::realVal() const
{
    return d_value;
}
