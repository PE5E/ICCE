#include "intvalue.ih"

void IntValue::vNegate()
{
    d_value = -d_value;
}
