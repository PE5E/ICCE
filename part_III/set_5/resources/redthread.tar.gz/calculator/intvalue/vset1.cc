#include "intvalue.ih"

void IntValue::vSet(Type, long long value)
{
    d_value = value;
}
