#include "intvalue.ih"

void IntValue::vSet(Type, double value)
{
    d_value = value;
}
