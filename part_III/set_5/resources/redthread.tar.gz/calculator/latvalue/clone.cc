#include "latvalue.ih"

ValueBase *LatValue::clone() const
{
    return new LatValue(value());
}
