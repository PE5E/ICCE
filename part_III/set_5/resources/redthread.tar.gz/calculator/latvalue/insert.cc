#include "latvalue.ih"

ostream &LatValue::insert(ostream &out) const
{
    return toLat(out, value());
}
