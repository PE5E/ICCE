#include "latvalue.ih"

LatValue::LatValue(double value)
:
    DoubleBase(LAT, value)
{}
