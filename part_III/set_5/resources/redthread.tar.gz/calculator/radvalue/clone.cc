#include "radvalue.ih"

ValueBase *RadValue::clone() const
{
    return new RadValue(value());
}
