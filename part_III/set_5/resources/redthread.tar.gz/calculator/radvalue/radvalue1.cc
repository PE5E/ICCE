#include "radvalue.ih"

RadValue::RadValue(double value)
:
    DoubleBase(RAD, value)
{}
