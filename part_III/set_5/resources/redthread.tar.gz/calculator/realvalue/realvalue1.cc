#include "realvalue.ih"

RealValue::RealValue(double value)
:
    DoubleBase(REAL, value)
{}
