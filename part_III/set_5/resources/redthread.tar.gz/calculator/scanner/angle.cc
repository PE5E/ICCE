#include "scanner.ih"

Token Scanner::angle(double value)
{
    cout << "value == " << value << ", ";

    ValueStruct const &vStruct = back2Type();

    cout << vStruct.type << ", " << vStruct.neg << '\n';

    d_value = Value::factory(vStruct.type, vStruct.neg ? -value : value);

    return Token::VALUE;
}

