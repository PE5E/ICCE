#include "scanner.ih"

Scanner::ValueStruct Scanner::back2Type()
{
    int last = tolower(matched().back());

    cout << "last char = " << (char)last << '\n';

    d_backChars.back() = last;

    cout << "backchars: " << d_backChars << ", idx = " << 
            d_backChars.find(last) << '\n';

    return  s_vType[d_backChars.find(last)];
}
