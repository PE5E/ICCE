#include "scanner.ih"

double Scanner::degSpec2()
{
    istringstream in(matched());

    size_t part1;
    in >> part1;
    in.ignore();

    size_t part2;
    in >> part2;
    in.ignore();

    return part1 + part2 / 60.0;
}

