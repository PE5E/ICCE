#include "scanner.ih"

Token Scanner::nr(size_t radix)
{
    string const &str = radix == 16 || radix == 2 ? 
                            matched().substr(2) : matched();

    size_t value = stoul(str, 0, radix);

    d_value = Value::factory(
                        str.back() == 'r' ? Value::RAD : Value::INT, 
                        value
                );

    return Token::VALUE;
}

