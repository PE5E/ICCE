#include "scanner.ih"

bool Scanner::radixNr()
{
    size_t pos = d_legalChars.find(tolower(matched()[0]));
    if (pos != string::npos)
    {
        d_radixOK = true;
        d_radixValue *= d_radix;
        d_radixValue += pos;
        return false;
    }        

    if (not d_radixOK)
        throw Exception() << "Value missing after " << d_radix << '\\';
    begin(StartCondition__::INITIAL);
    push(matched()[0]);
    d_value = Value::factory(Value::INT, d_radixValue);
    return true;    
}

