#include "scanner.ih"

Token Scanner::real()
{
    string const &str = matched();
    
    d_value = Value::factory(
                        str.back() == 'r' ? Value::RAD : Value::REAL, 
                        stod(str)
                    );

    return Token::VALUE;
}

