#include "scanner.ih"

Scanner::Scanner(std::istream &in, std::ostream &out)
:
    ScannerBase(in, out),
    d_backChars("dgrnesw "),     // must match s_vType[] (+ spare char)
    d_printTokens(Arg::instance().option('t'))
{}

