#include "symtab.ih"

void Symtab::clear()
{
    d_entry.clear();
}
