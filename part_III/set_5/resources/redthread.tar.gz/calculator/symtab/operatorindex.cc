#include "symtab.ih"

Value &Symtab::operator[](std::string const &name)
{
    if (d_entry[name] == 0)
        d_entry[name].reset(new Value);

    return *d_entry[name];
}
