//#include "symtab.ih"
//
//Symtab::const_iterator const &Symtab::operator[](size_t idx) const
//{
//    return *d_entry[idx];
//}
