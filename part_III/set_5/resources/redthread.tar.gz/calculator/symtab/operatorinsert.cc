#include "symtab.ih"

std::ostream &operator<<(std::ostream &out, Symtab::HashtabValue const &value)
{
    return out << value.first << ' ' << 
                  value.second->typeName() << ' ' << *value.second;
}
