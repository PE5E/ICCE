#ifndef INCLUDED_SYMTAB_
#define INCLUDED_SYMTAB_

#include <string>
#include <iosfwd>
#include <memory>
#include <unordered_map>

#include "../value/value.h"
#include "../function/function.h"

class Value;

struct Symtab
{
    typedef std::unordered_map< std::string, std::unique_ptr<Value>> Hashtab;
    typedef Hashtab::const_iterator const_iterator;
    typedef Hashtab::value_type HashtabValue;

        
    private:
        Function d_function;    // all predefined functions;
        Hashtab d_entry;

    public:
                                            // the args are non-const to
                                            // to allow type conversions for
                                            // functions.
        Value operator()(std::string const &name, size_t nArgs, Value *args) 
                                                                        const;
        Value &operator[](std::string const &name);
        const_iterator begin() const;
        const_iterator end() const;

        void clear();
        void list() const;

    private:
        static bool cmpNames(HashtabValue const *first, 
                            HashtabValue const *second);
};

std::ostream &operator<<(std::ostream &out, 
                         Symtab::HashtabValue const &value);

inline std::ostream &operator<<(std::ostream &out, 
                                    Symtab::const_iterator const &iter)
{
    return out << *iter;
}

inline Symtab::const_iterator Symtab::begin() const
{
    return d_entry.begin();
}

inline Symtab::const_iterator Symtab::end() const
{
    return d_entry.end();
}



#endif



