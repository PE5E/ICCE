#include "value.ih"

Value::Type Value::derefType() const
{
    return d_value->derefType();
}
