#include "value.ih"

Value::~Value()
{
    delete d_value;
}
