#include "value.ih"

Value Value::factory(double latitude, double longitude)
{
    Value ret(new FixValue(latitude, longitude));
    return ret;
}





