#include "value.ih"

double Value::latitude() const
{
    return d_value->latitude();
}
