#include "value.ih"

long long Value::longint() const
{
    return d_value->longint();
}
