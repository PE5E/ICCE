#include "value.ih"

double Value::longitude() const
{
    return d_value->longitude();
}
