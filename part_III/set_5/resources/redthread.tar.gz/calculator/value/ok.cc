#include "value.ih"

Value const &Value::ok(char const *operation, Value &lhs, Value &rhs,
                                                          Value const &right)
{
    return right;
}
