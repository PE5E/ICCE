#include "value.ih"

std::ostream &operator<<(std::ostream &out, Value const &value) 
{
    return out << *value.d_value;
}



