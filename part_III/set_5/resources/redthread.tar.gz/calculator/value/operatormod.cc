#include "value.ih"

Value operator%(Value const &lhs, Value const &rhs)
{
    Value ret(lhs);
    ret %= rhs;
    return ret;
}
