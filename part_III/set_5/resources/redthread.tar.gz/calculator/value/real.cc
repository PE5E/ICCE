#include "value.ih"

double Value::real() const
{
    return d_value->real();
}
