#include "value.ih"

void Value::set(double value)
{
    d_value->set(type(), value);
}
