#include "value.ih"

void Value::set(long long value)
{
    d_value->set(INT, value);       
}
