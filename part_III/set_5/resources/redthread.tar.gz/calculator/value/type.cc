#include "value.ih"

Value::Type Value::type() const
{
    return d_value->type();
}
