#include "value.ih"

Value::Value()
:
    Value(new RealValue())
{}
