#include "value.ih"

Value::Value(ValueBase *vBase)
:
    d_value(vBase)
{}
