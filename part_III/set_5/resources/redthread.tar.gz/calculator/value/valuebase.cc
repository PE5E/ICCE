#include "value.ih"

ValueBase const &Value::valueBase() const
{
    return *d_value;
}
