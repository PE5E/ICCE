#include "valuebase.ih"

ValueBase *ValueBase::copy() const
{
    return clone();
}
