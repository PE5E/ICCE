#include "valuebase.ih"

Value *ValueBase::deref()
{
    return vDeref();
}
