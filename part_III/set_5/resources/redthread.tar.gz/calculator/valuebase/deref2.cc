#include "valuebase.ih"

Value const *ValueBase::deref() const
{
    return vDeref();
}
