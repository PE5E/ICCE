#include "valuebase.ih"

ValueBase::Type ValueBase::derefType() const
{
    return vType();
}
