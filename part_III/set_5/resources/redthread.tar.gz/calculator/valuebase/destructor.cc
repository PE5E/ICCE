#include "valuebase.ih"

ValueBase::~ValueBase()
{}
