#include "valuebase.ih"

double ValueBase::latitude() const
{
    return latitudeVal();
}
