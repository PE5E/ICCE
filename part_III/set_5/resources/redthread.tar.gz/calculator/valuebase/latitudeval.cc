#include "valuebase.ih"

double ValueBase::latitudeVal() const
{
    wrongType("latitude");
    return 0;
}
