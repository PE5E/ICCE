#include "valuebase.ih"

long long ValueBase::longint() const
{
    return intVal();
}
