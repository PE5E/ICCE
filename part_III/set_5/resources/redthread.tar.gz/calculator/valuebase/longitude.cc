#include "valuebase.ih"

double ValueBase::longitude() const
{
    return longitudeVal();
}
