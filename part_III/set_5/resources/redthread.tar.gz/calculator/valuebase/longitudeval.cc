#include "valuebase.ih"

double ValueBase::longitudeVal() const
{
    wrongType("longitude");
    return 0;
}
