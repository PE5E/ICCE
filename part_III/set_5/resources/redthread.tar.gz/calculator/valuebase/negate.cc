#include "valuebase.ih"

void ValueBase::negate()
{
    vNegate();
}
