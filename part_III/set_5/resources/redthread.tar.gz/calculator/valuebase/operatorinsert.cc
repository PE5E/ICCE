#include "valuebase.ih"

std::ostream &operator<<(std::ostream &out, ValueBase const &value) 
{
    return value.insert(out);
}



