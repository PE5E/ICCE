#include "valuebase.ih"

double ValueBase::real() const
{
    return realVal();
}
