#include "valuebase.ih"

double ValueBase::realVal() const
{
    wrongType("real");
    return 0;
}
