#include "valuebase.ih"

void ValueBase::set(Type, long long value)
{
    vSet(INT, value);
}
