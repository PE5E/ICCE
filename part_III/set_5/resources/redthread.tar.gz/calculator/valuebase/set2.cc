#include "valuebase.ih"

void ValueBase::set(Type type, double value)
{
    vSet(type, value);
}
