#include "valuebase.ih"

ValueBase::Type ValueBase::type() const
{
    return d_type;
}
