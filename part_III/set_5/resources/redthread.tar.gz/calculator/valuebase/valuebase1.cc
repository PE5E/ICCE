#include "valuebase.ih"

ValueBase::ValueBase(Type type)
:
    d_type(type)
{}
