#include "valuebase.ih"

Value *ValueBase::vDeref() const
{
    throw logic_error("default ValueBase::vDeref called");
    return 0;
}
