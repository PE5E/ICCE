#include "valuebase.ih"

void ValueBase::vSet(Type, long long value)
{
    cantSet();
}
