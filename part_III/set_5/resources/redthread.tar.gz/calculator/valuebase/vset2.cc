#include "valuebase.ih"

void ValueBase::vSet(Type type, double value)
{
    cantSet();
}
