#include "valuebase.ih"

ValueBase::Type ValueBase::vType() const
{
    return d_type;
}
