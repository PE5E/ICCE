#include "valuetypes.ih"

char const *ValueTypes::typeName(Type type)
{
    return s_typeName[type];
}

