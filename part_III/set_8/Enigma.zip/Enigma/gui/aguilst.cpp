#include "gui.ih"

//make sorted list of QComboBox gui items identified by a reg exp
vector<QComboBox*> Gui::aGuiLst(QString const regex)
{
    //named lambda
    auto order = [](QComboBox* const p1, QComboBox* const p2)
                 {return p1->objectName() < p2->objectName();};

    QList<QComboBox*> lst;
    lst = findChildren<QComboBox*>(QRegularExpression(regex));
    std::sort(lst.begin(), lst.end(), order);

    vector<QComboBox*> vec;

    for(auto wdg: lst)
        vec.push_back(wdg);

    return vec;
}
