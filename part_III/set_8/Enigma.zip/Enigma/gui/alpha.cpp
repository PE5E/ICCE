#include "gui.ih"

//create range list from enigma's alphabet
//used to initialize combox's list of values likering and key settings and SB
vector<string> Gui::alpha() const
{
   vector<string>alpha{};
   for(size_t idx = 0; idx != Enigma::alphabetSze(); ++idx)
      alpha.push_back(string(1, Enigma::alphabet().at(idx)));

   return alpha;
}
