#include "gui.ih"

//make sorted lists of gui items to access them easily f.e. in for loops
//otherwise they have to be accessed explicitly by their textname
void Gui::bldGuiLsts()
{
   d_SB1 = aGuiLst("Plug1_\\d{2}$");
   d_SB2 = aGuiLst("Plug2_\\d{2}$");
   d_KRU = aGuiLst("Ri|Ke|Ro|UK");
}

