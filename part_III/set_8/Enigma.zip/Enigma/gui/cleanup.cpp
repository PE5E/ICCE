#include "gui.ih"

//initialize gui to starting conditions
//to be called after reconfig or reset button click
void Gui::cleanup()
{
    d_inputCnt = 0;
    d_pasteSze = 0;
    d_inputStr = "";
    d_inputChar = ' ';
    d_prevChar = ' ';

    ui->UserInput->clear();
    ui->EncOutput->clear();
    ui->debug->clear();
    d_enigma.reset();
}
