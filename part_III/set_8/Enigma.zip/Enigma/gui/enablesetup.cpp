#include "gui.ih"

//make fields, boxes, buttons accessible for setup if stat is true
//or disable them when stat is false
void Gui::enableSetup(bool const stat)
{
   //set plugboard to enabled/disabled
   for(size_t idx = 0; idx != d_SB1.size(); ++idx)
   {
      d_SB1.at(idx)->setEnabled(stat);
      d_SB2.at(idx)->setEnabled(stat);
   }

    //set rings and keys to enabled/disabled
   for(size_t idx = 0; idx != d_KRU.size(); ++idx)
      d_KRU.at(idx)->setEnabled(stat);

   ui->Reflector->setEnabled(stat);
   ui->UserInput->setEnabled(!stat);
   ui->EncOutput->setEnabled(!stat);
   ui->debug->setEnabled(!stat);
   ui->msgSze->setEnabled(!stat);
   ui->Configure->setEnabled(stat); //btns
   ui->Reconfig->setEnabled(!stat); //btns
   ui->Reset->setEnabled(!stat);    //btns
}
