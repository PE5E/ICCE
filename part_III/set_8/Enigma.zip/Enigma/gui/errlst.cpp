#include "gui.ih"

QString Gui::errLst() const
{
    //build string of config error(s)
    QString qerr{"Config error(s): "};
    if(!rflOk())       qerr += "rfl ";
    if(!rotorsOk())    qerr += "rotor(s) ";
    if(!ringsOk())     qerr += "ring(s) ";
    if(!keysOk())      qerr += "key(s) ";
    if(!plugboardOk()) qerr += "plugboard";

    return qerr;
}
