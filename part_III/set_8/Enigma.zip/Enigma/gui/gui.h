#ifndef GUI_H
#define GUI_H

//QStuff
#include <QMainWindow>
#include <QComboBox>
#include <QList>

//C++ stuff
#include <vector>
#include <string>
using std::vector;
using std::string;

//EnigmaLib stuff
#include "../enigma/enigma.h"

namespace Ui {
  class Gui;
}

class Gui : public QMainWindow         //derived class
{
    Q_OBJECT                           //calls Qt pre-processor

public:
    explicit Gui(QWidget *parent = 0); //copy const and implicit initialization not allowed
    ~Gui();

private slots:                         //not C++ slang
    void on_Configure_clicked();       //setup selected rotors/rings/keys/UKW/SB
    void on_Reconfig_clicked();        //do setup again
    void on_Reset_clicked();           //clear input, reset rotors to starting cfg
    void on_UserInput_textChanged();   //analyze input, repair input or encrypt

private:
    Enigma d_enigma;
    Ui::Gui *ui;

    bool d_guimod;                 //indicate if user or gui modified input

    using vecCoBx = vector<QComboBox*>;

    vecCoBx d_SB1;       //points to the GUI SB fields in first row
    vecCoBx d_SB2;       //points to the GUI SB fields in second row
    vecCoBx d_KRU;       //points to GUI Key, Ring, Rotor, UKW fields

    size_t const d_keyAt  = 0 * Enigma::rotorCnt(); //in  gui list d_KRU, key starts at 0
    size_t const d_ringAt = 1 * Enigma::rotorCnt(); //and ring elements start at rotorCnt()
    size_t const d_rotAt  = 2 * Enigma::rotorCnt(); //rot elements start at 2 * d_rotorCnt()

    size_t d_inputCnt;             //counts #chars in input box
    size_t d_pasteSze;             //how many chars were pasted (>= 1)
    string d_inputStr;             //user input keyed in so far cleaned of illegal chars
    char d_inputChar, d_prevChar;  //house keeping to handle user input (errors)

    string const d_version = "4.1 21-03-2018";

    enum class inpKnd {LegalCh, Blank, Pasted, WrongCh, BS}; //input classification
    enum posR {roR = 0, roM, roL}; //enum rotor positions, future: with 4 rots use roM1, roM2

    vector<string>alpha() const;   //returns enigma alfabet chars in a vector
    vecCoBx aGuiLst(QString const regex); //create a sorted Gui lst matching regex
    void bldGuiLsts();             //list of plugboard, rings and keys to shorten coding
    void cleanup();                //reset house keeping after click reset/reconfig
    void enableSetup(bool stat);   //stat = true/false => you can/can't modify setup
    QString errLst() const;        //return list of errors in config setup
    void inclPic();                //load enigma picture
    void initRingKey();            //add selectable chars to ring and key
    void initSB();                 //add selectable chars to plugboard starting with ""
    inpKnd inputType();            //determine kind of input in UserInp text box
    void insertRfl();              //used in setUpEnigma(), insert selected reflector
    void insertRotors();           //used in setUpEnigma(), insert selected rotors
    bool inAlphabet(char ch) const;//checks if ch is in the selectable alphabet of Enigma
    QStringList itemLst(vector<string> const &lst) const; //convert vector to QStringList
    bool keysOk() const;           //check all key settings are non-empty
    void loadPlugBoard();          //used in setUpEnigma(), copies plugboard from screen
    bool plugboardOk() const;      //check plugboard for ambiguous plugs like (AB) and (BD)
    void processChar(QChar const &qch); //act on one char for encryption and update GUI
    void processPaste();           //process the pasted text, encrypt and update gui
    void repairInp(inpKnd knd);    //clear input of illegal chars !(Enigma alphabet || space)
    bool rflOk() const;            //check rfl is non-empty
    bool ringsOk() const;          //check all ring settings are non-empty
    bool rotorsOk() const;         //check that all selected rotors are different
    void rotorView() const ;       //show updated rotors after rotation
    void setPlug(vector<size_t>&vecSB,
                 QString const &pb1,
                 QString const &pb2); //insert a plug combination like (U, X) in vecSB
    void setRanges();              //set ranges for ring, key
    void setRflLst();              //add available reflectors to Refelector selection list
    void setRotLst();              //add available rotors to Rotor selection lists
    void setUpEnigma();            //configure the eniga
    void showVersion() const;
    void updWindow(char ch);       //update mainwindow after encryption step
    void updWindow();              //update mainwindow after reset
};

#endif // GUI_H
