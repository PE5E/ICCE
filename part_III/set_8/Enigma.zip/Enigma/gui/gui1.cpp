#include "gui.ih"

Gui::Gui(QWidget *parent)
: QMainWindow(parent), ui(new Ui::Gui),
  d_guimod(false),
  d_inputCnt(0), d_pasteSze(0), d_inputStr{},
  d_inputChar(' '), d_prevChar(' ')
{
    ui->setupUi(this);
    ui->Reflector->setFocus();

    bldGuiLsts();
    enableSetup(true); //make setup fields on Gui accessible
    setRanges();       //set lists of rotors and reflectors, set alphabet range
    showVersion();
    inclPic();
}
