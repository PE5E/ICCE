#include "gui.ih"

Gui::~Gui()
{
    delete ui;
}
