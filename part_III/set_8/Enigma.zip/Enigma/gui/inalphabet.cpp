#include "gui.ih"

bool Gui::inAlphabet(char ch) const
{
   return Enigma::alphabet().find(toupper(ch)) != string::npos;
}
