#include "gui.ih"

void Gui::inclPic()
{
   QPixmap img("../Enigma/pics/enigma-style.gif");
   ui->picEnigma->setPixmap(img);
}
