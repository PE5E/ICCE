#include "gui.ih"

void Gui::initRingKey()
{
    //skip Rotor_L, _M, _R, only Ring and Key have range list
    //add selectable items (the alphabet) for Ring & Key
    for(size_t idx = 0; idx != d_KRU.size(); ++idx)
      if(d_KRU.at(idx)->objectName().toStdString().find("Rotor_") == string::npos)
         d_KRU.at(idx)->addItems(itemLst(alpha()));
}
