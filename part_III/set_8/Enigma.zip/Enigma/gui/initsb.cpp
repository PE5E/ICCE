#include "gui.ih"

void Gui::initSB()
{
    for(size_t idx = 0; idx != d_SB1.size(); ++idx)
    {
      //add selectable items (the alphabet) for the plugboard
      d_SB1.at(idx)->addItems(itemLst(alpha()));
      d_SB2.at(idx)->addItems(itemLst(alpha()));
    }
}
