#include "gui.ih"

//read input and analyze kind of input
Gui::inpKnd Gui::inputType()
{
    d_inputStr = ui->UserInput->toPlainText().toStdString();

    //empty str or less chars in input than previously => BS was pressed
    if(!d_inputStr.length() || d_inputStr.length() < d_inputCnt)
      return inpKnd::BS;

    //d_inputStr not empty, now we can retrieve input char
    //and determine how many chars were added
    d_inputChar = d_inputStr.at(d_inputStr.length() - 1);
    d_pasteSze = d_inputStr.length() - d_inputCnt;

    if(d_pasteSze != 1)          return inpKnd::Pasted;  //more than one char added
    if(d_inputChar == ' ')       return inpKnd::Blank;   //spacing
    if(!inAlphabet(d_inputChar)) return inpKnd::WrongCh; //not in Enigma alphabet

    return inpKnd::LegalCh; //encrypt this one
}
