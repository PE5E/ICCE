#include "gui.ih"

void Gui::insertRfl()
{
    //currentText() contains refelector name as QText type
    //toStdString() converts it to string
    d_enigma.setRfl(ui->Reflector->currentText().toStdString());

    //show reflector lay-out (wiring)
    ui->UKW->setText(QString::fromStdString(*d_enigma.rflMap()));
}
