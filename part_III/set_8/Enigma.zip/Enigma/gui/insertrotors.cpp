#include "gui.ih"

//plug the three gui selected rotors in the enigma
//convert QString name id to std string
//convert key and ring values to range 0 .. Enigma::wireSze() - 1
//show rotor lay-outs
void Gui::insertRotors()
{
    //due to alphabetic ordering of GUI lst with idx in 0, 1, ... , Enigma::rotorCnt:
    //d_KRU.at(d_rotAt  + idx) is ui->Rotor_L, _M, _R with value rotId
    //d_KRU.at(d_keyAt  + idx) is ui->Key_L, _M, _R
    //d_KRU.at(d_ringAt + idx) is ui->Ring_L, _M, _R
    for(size_t idx = 0;idx != Enigma::rotorCnt(); ++idx)
      d_enigma.setRot(2 - idx,
                      d_KRU.at(d_rotAt  + idx)->currentText().toStdString(),
                      d_KRU.at(d_keyAt  + idx)->currentText().at(0).toLatin1() - 'A',
                      d_KRU.at(d_ringAt + idx)->currentText().at(0).toLatin1() - 'A');

    d_enigma.reset(); //set steps made by rotors to 0

    //show rotor lay-out
    ui->rot_L->setText(QString::fromStdString(*d_enigma.rotMap(roL)));
    ui->rot_M->setText(QString::fromStdString(*d_enigma.rotMap(roM)));
    ui->rot_R->setText(QString::fromStdString(*d_enigma.rotMap(roR)));
}

