#include "gui.ih"

//builds a QStringList of string items stored in a vector lst
QStringList Gui::itemLst(vector<string> const &lst) const
{
   QStringList qsl{""};

   for(auto it = lst.begin(); it != lst.end(); ++it)
      qsl << QString::fromStdString(*it);

   return qsl;
}
