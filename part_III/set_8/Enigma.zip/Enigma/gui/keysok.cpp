#include "gui.ih"

//key values can't be empty
bool Gui::keysOk() const
{
   return ui->Key_L->currentText().length() &&
          ui->Key_M->currentText().length() &&
          ui->Key_R->currentText().length();
}
