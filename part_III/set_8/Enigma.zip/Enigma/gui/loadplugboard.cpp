#include "gui.ih"

//read the plugboard configuration from the GUI,
//build the wiring set and return Wiring object
void Gui::loadPlugBoard()
{
   vector<size_t>vecSB;

   //initialize SB to nothing plugged
   //i.e. SB[0] == 0, SB[1] == 1, ... or (A,A), (B, B), ...
   for(size_t idx = 0; idx != Enigma::alphabetSze(); ++idx)
      vecSB.push_back(idx);

   //read plugboard configuration from screen
   for(size_t idx = 0; idx != d_SB1.size(); ++idx)
      setPlug(vecSB, d_SB1.at(idx)->currentText(),
                     d_SB2.at(idx)->currentText());

   d_enigma.cfgPlgBd(vecSB);
}
