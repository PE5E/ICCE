#include "gui.ih"

//check if configuration (setup) was defined ok
//otherwise return message indicating error source(s)
void Gui::on_Configure_clicked()
{
   if(rflOk() &&
      rotorsOk() && ringsOk() && keysOk() &&
      plugboardOk())
   {
      ui->SetupChk->setPlainText("Configuration Ok");
      enableSetup(false); //no access anymore to setup fields in Gui
      setUpEnigma();      //put Enigma parts together
      return;
   }

   ui->SetupChk->setPlainText(errLst());
}
