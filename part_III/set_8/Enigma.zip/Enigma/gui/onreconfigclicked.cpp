#include "gui.ih"

//bring enigma to the initial state where you can
//select rotors, plugboard and reflector
void Gui::on_Reconfig_clicked()
{
    d_guimod = true;
    cleanup();
    enableSetup(true);
    ui->SetupChk->clear();
    ui->Reflector->setFocus();
}
