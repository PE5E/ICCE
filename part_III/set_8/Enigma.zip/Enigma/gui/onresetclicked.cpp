#include "gui.ih"

//reset brings the enigma back to the situation where rotors and refelector
//and plugboard were selected but no input was received yet
//this can be used to start decryption process
void Gui::on_Reset_clicked()
{
    d_guimod = true;
    cleanup();   //reset house keeping
    updWindow(); //update view on rotor
}
