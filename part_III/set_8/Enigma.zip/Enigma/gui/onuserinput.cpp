#include "gui.ih"

//launch action depending on the kind of input given
void Gui::on_UserInput_textChanged()
{ 
    if(d_guimod) //was the input text changed by gui for repair?
    {
       d_guimod = false;
       return;  //then nothing to do
    }

    switch(inputType())
    {
       case inpKnd::Blank:
            ++d_inputCnt;
            d_prevChar = ' ';
            break;
       case inpKnd::LegalCh:
            processChar(d_inputChar);
            break;
       case inpKnd::Pasted:
            processPaste();
            break;
       case inpKnd::WrongCh:
       case inpKnd::BS:
            d_guimod = true;
            repairInp(inputType());
    }
}
