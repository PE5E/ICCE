#include "gui.ih"
#include<iterator>

// check for plugboard errors like AB and BD where B is twice connected
// all plugboard entries must be either (ch, ch) or (ch1, ch2) with ch1 != ch2
// incomplete pairs (ch,) and (, ch) are in error
bool Gui::plugboardOk() const
{
   //pairwise checking "Plug1_01" vs "Plug2_01", "Plug1_02" vs "Plug2_02"
   for (size_t idx = 0; idx != d_SB1.size(); ++idx)
       if (d_SB1.at(idx)->currentText().length() != d_SB2.at(idx)->currentText().length())
          return false;

   vector<size_t>cnt(Enigma::alphabetSze(), 0);

   for (size_t idx = 0; idx != d_SB1.size(); ++idx)
       if(d_SB1.at(idx)->currentText().length() != 0)
       {
          cnt[d_SB1.at(idx)->currentText().at(0).toLatin1() - 'A']++;
          cnt[d_SB2.at(idx)->currentText().at(0).toLatin1() - 'A']++;
       }

   //check for ambiguous assignments like (AB) (BK)
   for (auto idx = cnt.begin(); idx != cnt.end(); ++idx)
       if (*idx != 1 && *idx != 0) return false;

   return true;
}


