#include "gui.ih"

//encrypt one (legal) char and put the result in the output box
void Gui::processChar(QChar const &qch)
{
    //ensure uppercase & convert to char
    char ch = qch.toUpper().toLatin1();
    ++d_inputCnt;

    d_prevChar = ch;        //to repair input if BS was pressed hereafter
    ch = d_enigma.encrypt(ch);
    updWindow(ch);
}
