#include "gui.ih"

//process the pasted text char by char and skip all non letter chars
//always increase d_inputCnt
void Gui::processPaste()
{
    size_t startAt = d_inputCnt;
    for(size_t idx = 0; idx != d_pasteSze; ++idx)
    {
        d_inputChar = d_inputStr.at(startAt + idx);
        if(inAlphabet(d_inputChar))
          processChar(d_inputChar);
        else
           ++d_inputCnt;
    }
}
