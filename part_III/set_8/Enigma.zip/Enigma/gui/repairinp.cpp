#include "gui.ih"

void Gui::repairInp(inpKnd knd)
{
   if(knd == inpKnd::WrongCh) d_inputStr.pop_back(); //delete last char
   if(knd == inpKnd::BS) d_inputStr += d_prevChar;   //restore deleted char

   //restore input screen and set cursor at end of text to ensure
   //that next chars will be added at the end
   ui->UserInput->setPlainText(QString::fromLatin1(d_inputStr.c_str()));
   ui->UserInput->moveCursor(QTextCursor::End);
}
