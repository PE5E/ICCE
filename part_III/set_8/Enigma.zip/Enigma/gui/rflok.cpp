#include "gui.ih"

//reflector cannot be empty
bool Gui::rflOk() const
{
   return ui->Reflector->currentText().length();
}
