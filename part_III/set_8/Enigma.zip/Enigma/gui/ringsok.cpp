#include "gui.ih"

//ring values may not be empty
bool Gui::ringsOk() const
{
   return ui->Ring_L->currentText().length() &&
          ui->Ring_M->currentText().length() &&
          ui->Ring_R->currentText().length();
}
