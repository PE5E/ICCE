#include "gui.ih"

//check for selection of 3 different rotors
//L <> M, M <> R, L <> R and
//3 rotors selected (length of string textfield <> 0)
bool Gui::rotorsOk() const
{
  return ui->Rotor_L->currentText() != ui->Rotor_M->currentText() &&
         ui->Rotor_L->currentText() != ui->Rotor_R->currentText() &&
         ui->Rotor_M->currentText() != ui->Rotor_R->currentText() &&
         ui->Rotor_L->currentText().length() &&
         ui->Rotor_M->currentText().length() &&
         ui->Rotor_R->currentText().length();
}
