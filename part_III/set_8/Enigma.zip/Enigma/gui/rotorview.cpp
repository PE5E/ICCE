#include "gui.ih"

void Gui::rotorView() const
{
    //update rotor positions after encryption step
    ui->ViewRotor_L->setText(QString(char(d_enigma.rotView(roL) + 'A')));
    ui->ViewRotor_M->setText(QString(char(d_enigma.rotView(roM) + 'A')));
    ui->ViewRotor_R->setText(QString(char(d_enigma.rotView(roR) + 'A')));
}
