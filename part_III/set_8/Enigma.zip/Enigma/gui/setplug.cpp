#include "gui.ih"

//connect two entries pb1 and pb2 on the plugboard
//results in permution (pb1 pb2)
void Gui::setPlug (vector<size_t>&vecSB, QString const &pb1, QString const &pb2)
{
   //if pb1 (and thus also pb2) is empty (size 0) then no plug was set, then skip
   if(pb1.size())
   {
      char ch1 = pb1.at(0).toLatin1() - 'A';
      char ch2 = pb2.at(0).toLatin1() - 'A';
      vecSB.at(ch1) = ch2;
      vecSB.at(ch2) = ch1;
   }
}
