#include "gui.ih"

//set ranges 1 .. alfabetSze() that can be selected for ring and key
//show available rotors and reflectors
void Gui::setRanges()
{
    setRotLst();
    setRflLst();
    initSB();      //init SB to blank with alphabet as range
    initRingKey(); //init to alphabet with 'A' as first selection
}
