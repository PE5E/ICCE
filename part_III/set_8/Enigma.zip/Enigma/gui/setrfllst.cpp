#include "gui.ih"

void Gui::setRflLst()
{
    //retrieve available reflectors and put them in the Reflector list
    ui->Reflector->addItems(itemLst(*d_enigma.rflLst()));
}
