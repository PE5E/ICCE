#include "gui.ih"

void Gui::setRotLst()
{
    //retrieve available rotor ids
    for(size_t idx = d_rotAt; idx != d_rotAt + Enigma::rotorCnt(); ++idx)
       d_KRU.at(idx)->addItems(itemLst(*d_enigma.rotLst()));
}
