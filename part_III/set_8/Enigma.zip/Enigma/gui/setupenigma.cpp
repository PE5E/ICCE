#include "gui.ih"

void Gui::setUpEnigma()
{
   loadPlugBoard();
   insertRotors();
   insertRfl();
   updWindow();       //rotor view starting positions
}
