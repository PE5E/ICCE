#include "gui.ih"

//shows Enigma build version and GUI version
void Gui::showVersion() const
{
    QString qs{qs.fromStdString("EnigmaLib Bld: " + *d_enigma.version() + " / " +
                                "EnigmaGUI Bld: " + d_version)};
    ui->Version->setText(qs);
    ui->Version->adjustSize(); //fit output field to qs size
}
