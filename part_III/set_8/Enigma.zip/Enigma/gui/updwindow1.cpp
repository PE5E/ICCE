#include "gui.ih"

//update screenfields of output, message size and debug info
//show the rotor position (how much the rotors have turned)
void Gui::updWindow(char ch)
{
    //add encrypted char to output, show debug and update rotor window
    QString str(ui->EncOutput->toPlainText() + QChar(ch));
    ui->EncOutput->setPlainText(str);
    ui->msgSze->setText(QString::number(str.size()));
    ui->debug->setPlainText(QString::fromStdString(*d_enigma.debugEnc()));

    //update rotor positions after encryption step
    rotorView();
}
