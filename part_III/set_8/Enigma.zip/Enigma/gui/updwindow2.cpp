#include "gui.ih"

//update window used in reset and setup, show #char encrypted
//show the rotor position (how much the rotors have turned)
//and the size of the output text (blanks in input are not considered)
void Gui::updWindow()
{
    ui->msgSze->setText(QString::number(0));

    //update rotor positions after encryption step
    rotorView();
}
