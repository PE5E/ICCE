#include <QApplication>
#include "gui/gui.ih"

int main(int argc, char *argv[])
{
   QApplication app(argc, argv);

   Gui enigma;
   enigma.show();

   return app.exec();

}
