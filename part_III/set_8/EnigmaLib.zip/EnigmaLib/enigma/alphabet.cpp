#include "enigma.ih"

std::string Enigma::alphabet()
{
  return EnigmaImpl::alphabet();
}
