#include "enigma.ih"

size_t Enigma::alphabetSze()
{
  return EnigmaImpl::alphabetSze();
}
