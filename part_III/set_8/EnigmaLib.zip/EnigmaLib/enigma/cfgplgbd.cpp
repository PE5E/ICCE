#include "enigma.ih"

void Enigma::cfgPlgBd(vector<size_t> const &vecSB)
{
   d_EnigmaImpl->cfgPlgBd(vecSB);
}
