#include "enigma.ih"

bool Enigma::chkPlgBd(vector<size_t> const &vecSB) const
{
   return d_EnigmaImpl->chkPlgBd(vecSB);
}
