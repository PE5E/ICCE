#include "enigma.ih"

string *Enigma::debugEnc() const
{
   return d_EnigmaImpl->debugEnc();
}
