#include "enigma.ih"

void Enigma::dmpSetup() const
{
   d_EnigmaImpl->dmpSetup();
}
