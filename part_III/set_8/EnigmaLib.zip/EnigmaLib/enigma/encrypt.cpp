#include "enigma.ih"

char Enigma::encrypt(char ch)
{
   return d_EnigmaImpl->encrypt(ch);
}
