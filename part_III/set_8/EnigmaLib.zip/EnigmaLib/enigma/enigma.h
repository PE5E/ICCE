#ifndef ENIGMA_H
#define ENIGMA_H

#include <cstddef>
#include <string>
#include <vector>

class EnigmaImpl;

class Enigma {

    EnigmaImpl *d_EnigmaImpl;

public:
    Enigma();
    ~Enigma();
    
    //Enigma's content: alfabet, reflectors and rotors
    static std::string alphabet();           //the alphabet that can be used
    static size_t alphabetSze();             //size of the alfabet in use
    static size_t rotorCnt();                //number of installed rotors
    std::vector<std::string>*rflLst() const; //ref to list avialable reflectors
    std::vector<std::string>*rotLst() const; //ref to list avialable rotors

    //setup Enigma and reset Enigma
    void setRfl(std::string const &rflId);                 //install reflector with rflId
    void setRot(size_t rPos, std::string const &rotId, size_t key, size_t ring);
                                                           //rotor with rotId at position rPos
    bool chkPlgBd(std::vector<size_t> const &vecSB) const; //check if plugboard setting is ok
    void cfgPlgBd(std::vector<size_t> const &vecSB);       //configure plugboard
    void reset();                                          //reset/initalize (0 chars typed)

    //encryption and view on (turned) rotors
    char encrypt(char ch);                   //encrypt one char 
    size_t rotView(size_t rPos) const;       //returns visible ringkey of rotor
    
    //debug, setup details & version 
    void dmpSetup() const;                   //dump enigma setup to cerr
    std::string *debugEnc() const;           //returns steps of encrypt(ch)
    std::string *rotMap(size_t rPos) const;  //layout installed rotor
    std::string *rflMap() const;             //layout installed reflector
    std::string *version() const;            //version number   
};

#endif //ENIGMA_H
