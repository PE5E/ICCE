#include "enigma.ih"

Enigma::Enigma()
  : d_EnigmaImpl(new EnigmaImpl)
{

}
