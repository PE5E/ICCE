#include "enigma.ih"

Enigma::~Enigma()
{
   delete d_EnigmaImpl;
}
