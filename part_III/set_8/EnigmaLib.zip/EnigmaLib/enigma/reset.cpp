#include "enigma.ih"

void Enigma::reset()
{
   d_EnigmaImpl->reset();
}
