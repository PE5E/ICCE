#include "enigma.ih"

vector<string> *Enigma::rflLst() const
{
   return d_EnigmaImpl->rflLst();
}
