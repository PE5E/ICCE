#include "enigma.ih"

string *Enigma::rflMap() const
{
   return d_EnigmaImpl->rflMap();
}
