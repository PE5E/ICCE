#include "enigma.ih"

vector<string> *Enigma::rotLst() const
{
   return d_EnigmaImpl->rotLst();
}
