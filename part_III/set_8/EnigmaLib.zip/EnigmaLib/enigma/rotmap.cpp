#include "enigma.ih"

string *Enigma::rotMap(size_t rPos) const
{
   return d_EnigmaImpl->rotMap(rPos);
}
