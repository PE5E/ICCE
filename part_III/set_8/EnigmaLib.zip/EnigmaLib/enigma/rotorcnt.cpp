#include "enigma.ih"

size_t Enigma::rotorCnt()
{
  return EnigmaImpl::rotorCnt();
}
