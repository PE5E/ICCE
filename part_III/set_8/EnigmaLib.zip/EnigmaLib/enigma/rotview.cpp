#include "enigma.ih"

size_t Enigma::rotView(size_t rPos) const
{
   return d_EnigmaImpl->rotView(rPos);
}
