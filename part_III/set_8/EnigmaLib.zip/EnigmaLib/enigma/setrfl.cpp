#include "enigma.ih"

void Enigma::setRfl(string const &rflId)
{
   d_EnigmaImpl->setRfl(rflId);
}
