#include "enigma.ih"

void Enigma::setRot(size_t rPos, string const &rotId, size_t key, size_t ring)
{
   d_EnigmaImpl->setRot(rPos, rotId, key, ring);
}
