#include "enigma.ih"

string *Enigma::version() const
{
   return d_EnigmaImpl->version();
}
