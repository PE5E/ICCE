#include "enigmaimpl.ih"

string EnigmaImpl::alphabet()
{
  return Wiring::alphabet();
}
