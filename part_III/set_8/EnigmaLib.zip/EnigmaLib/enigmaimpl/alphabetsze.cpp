#include "enigmaimpl.ih"

size_t EnigmaImpl::alphabetSze()
{
  return Wiring::alphabet().size();
}
