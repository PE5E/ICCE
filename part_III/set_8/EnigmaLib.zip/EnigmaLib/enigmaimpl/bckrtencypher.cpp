#include "enigmaimpl.ih"

//encryption in reverse direction is done by finding
//the forward indx that results to idx_inp
size_t EnigmaImpl::bckRtEncypher(encStp rPos, size_t inp) const
{
   Rotor *rot = d_rots.Rot.at(rPos);
   size_t ring = d_rots.Ring.at(rPos);

   //map inp on the rotor
   inp = (inp + 
	  alphabetSze() - ring +
          rotView(rPos))
          % alphabetSze();

   //find matching outp and return that after applying inverse map
   for(size_t outp = 0; outp != alphabetSze(); ++outp)
     if(inp == rot->rotWr().permute(outp))
       return (outp +
	       ring +
               alphabetSze() - rotView(rPos))
               % alphabetSze();

   throw "No encryption possible in bckRtEncypher";
}
