#include "enigmaimpl.ih"

//encryption in reverse direction is done by finding
//the forward indx that results to the input indx
size_t EnigmaImpl::bckWrEncypher(Wiring const &wr, size_t inp) const
{
  for(size_t outp = 0; outp != alphabetSze(); ++outp)
    if(wr.permute(outp) == inp) return outp;

  throw "No encryption possible in bckWrEncypher";
}
