#include "enigmaimpl.ih"

//put plugboard settings into Enigma
void EnigmaImpl::cfgPlgBd(vector<size_t> const &vecSB)
{
  string SB{};
  for(auto it = vecSB.begin(); it != vecSB.end(); ++it)
     SB += *it;

  d_SB.bldWiring("SB", SB);
}
