#include "enigmaimpl.ih"

//check plugboard settings:every char of enigma alphabet occurs once
bool EnigmaImpl::chkPlgBd(vector<size_t> const &vecSB) const
{
  vector<size_t>cnt(alphabetSze(), 0);

  for(auto it = vecSB.begin(); it != vecSB.end(); ++it)
  {
    ++cnt.at(*it);
    if(cnt.at(*it) != 1) return false;
  }  

  return true;
}
