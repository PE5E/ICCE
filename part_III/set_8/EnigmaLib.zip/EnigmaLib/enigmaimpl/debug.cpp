#include "enigmaimpl.ih"

//buid debug output of steps through SB ETW Rotors and UKW
void EnigmaImpl::debug(encStp stp, size_t ch)
{
  string s{};
  s += (ch + 'A');
  string step{StpToStr(stp)};
  
  if(step == "UKW")
    *d_debug += "\n(" + step + "=>" + s + ")\n";
  else if(step == "ETW" &&
	  d_debug->length() == 7)              //len 7 passing ETW fwd
    *d_debug += "(" + step + "=>" + s + ")\n";
  else if(step == "ETW")                       //passing ETW bck
    *d_debug += "\n(" + step + "=>" + s + ")";
  else                                         //passing a rotor
    *d_debug += "(" + step + "=>" + s + ")";
}
