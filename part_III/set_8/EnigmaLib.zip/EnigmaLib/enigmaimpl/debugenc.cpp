#include "enigmaimpl.ih"

string *EnigmaImpl::debugEnc()
{
    return d_debug;
}
