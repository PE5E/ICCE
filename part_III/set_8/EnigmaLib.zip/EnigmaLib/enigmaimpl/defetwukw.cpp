#include "enigmaimpl.ih"

//define entry board ETW and reflectors UKW-*
void EnigmaImpl::defETWUKW()
{
    d_ETW.bldWiring("ETW", "ABCDEFGHIJKLMNOPQRSTUVWXYZ");

    d_UKW_A.bldWiring("UKW-A", "EJMZALYXVBWFCRQUONTSPIKHGD");
    d_rflLst->push_back("UKW-A");

    d_UKW_B.bldWiring("UKW-B", "YRUHQSLDPXNGOKMIEBFZCWVJAT");
    d_rflLst->push_back("UKW-B");

    d_UKW_C.bldWiring("UKW-C", "FVPJIAOYEDRZXWGCTKUQSBNMHL");
    d_rflLst->push_back("UKW-C");
}
