#include "enigmaimpl.ih"

//define the available rotors
void EnigmaImpl::defRotors()
{
   //turnover = 'Q' = 16, where 'A' = 0 and 'Z' = 25
   d_I.bldRotor(Wiring("I", "EKMFLGDQVZNTOWYHXUSPAIBRCJ"), {16});
   d_rotLst->push_back("I");

   d_II.bldRotor(Wiring("II", "AJDKSIRUXBLHWTMCQGZNPYFVOE"), {4});
   d_rotLst->push_back("II");

   d_III.bldRotor(Wiring("III", "BDFHJLCPRTXVZNYEIWGAKMUSQO"), {21});
   d_rotLst->push_back("III");

   d_IV.bldRotor(Wiring("IV", "ESOVPZJAYQUIRHXLNFTGKDCMWB"), {9});
   d_rotLst->push_back("IV");

   d_V.bldRotor(Wiring("V","VZBRGITYUPSDNHLXAWMJQOFECK"), {25});
   d_rotLst->push_back("V");

   d_VI.bldRotor(Wiring("VI", "JPGVOUMFYQBENHZRDKASXLICTW"), {12, 25});
   d_rotLst->push_back("VI");

   d_VII.bldRotor(Wiring("VII", "JPGVOUMFYQBENHZRDKASXLICTW"), {12, 25});
   d_rotLst->push_back("VII");

   d_VIII.bldRotor(Wiring("VIII", "FKQHTLXOCBJSPDZRAMEWNIUYGV"), {12, 25});
   d_rotLst->push_back("VIII");
}
