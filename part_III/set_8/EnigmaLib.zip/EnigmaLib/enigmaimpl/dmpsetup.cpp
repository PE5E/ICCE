#include "enigmaimpl.ih"

void EnigmaImpl::dmpSetup() const
{
   for(size_t idx = 0; idx != s_rotorCnt; ++idx)
   {
      std::cerr << "RotId = " << d_rots.Rot.at(idx)->rotId()
                << " Key = "  << d_rots.Key.at(idx)
                << " Ring = " << d_rots.Ring.at(idx)
                << '\n';
   }
   std::cerr << "Reflector = " << d_UKW->wireId() << '\n';
}
