#include "enigmaimpl.ih"

//encryption follows the permutation steps:
//SB > ETW > RR > RM > RL > UKW > RLInv > RMInv > RRInv > ETWInv > SBInv
//rotor position: rightmost rotor = 0 and leftmost rotor = rotorCnt - 1
char EnigmaImpl::encrypt(char ch)
{
    turnRots();    //prior to encryption turn the rotor(s)
    *d_debug = ""; //init debug string
    ch = ch - 'A'; //bring input in range 0 .. wireSze()

    ch = fwdWrEncypher(d_SB, ch);  debug(SB, ch);
    ch = fwdWrEncypher(d_ETW, ch); debug(ETW, ch);

    ch = fwdRtEncypher(roR, ch); debug(roR, ch);
    ch = fwdRtEncypher(roM, ch); debug(roM, ch);
    ch = fwdRtEncypher(roL, ch); debug(roL, ch);

    ch = fwdWrEncypher(*d_UKW, ch); debug(UKW, ch);
   
    ch = bckRtEncypher(roL, ch); debug(roL, ch);
    ch = bckRtEncypher(roM, ch); debug(roM, ch);
    ch = bckRtEncypher(roR, ch); debug(roR, ch);

    ch = bckWrEncypher(d_ETW, ch); debug(ETW, ch);
    ch = bckWrEncypher(d_SB, ch);  debug(SB, ch);

    return ch + 'A';  
}
