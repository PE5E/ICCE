#ifndef ENIGMAIMPL_H
#define ENIGMAIMPL_H

#include <cstddef>
#include "../wiring/wiring.h"
#include "../rotor/rotor.h"
#include "../using.ih"

class Wiring;
class Rotor;

class EnigmaImpl{

public:
    EnigmaImpl();
    ~EnigmaImpl();

    //what's in the enigma setup box
    static size_t alphabetSze();           //size of the alfabet set
    static string alphabet();              //the alfabet that can be used
    static size_t rotorCnt();              //number of installed rotors
    vector<string> *rotLst() const;        //ref to list avialable rotors
    vector<string> *rflLst() const;        //ref to list avialable reflectors

    //for setup by gui
    void setRfl(string const &rflId);
    void setRot(size_t rPos, string const &rotId, size_t key, size_t ring);
    void cfgPlgBd(vector<size_t> const &vecSB);
    bool chkPlgBd(vector<size_t> const &vecSB) const;
    void reset();                          //back to begin of input

    //for debug
    string *debugEnc();                    //returns steps of encrypt(ch)
    void dmpSetup() const;                 //dump setup on cerr
    string *rotMap(size_t rPos) const;     //layout installed rotor
    string *rflMap() const;                //layout installed reflector
    string *version() const;               //version number

    //the encryption and the turned rotors
    char encrypt(char ch);
    size_t rotView(size_t rPos) const;     //returns visible ring nr of rotor

private:

    enum encStp{SB = -2, ETW,
          	roR, roM, roL, UKW};       //enumerating enc steps, roR = 0

    static size_t const s_rotorCnt = 3;
    struct rotors{
       array<Rotor*, s_rotorCnt>Rot;       //pointers to choosen rotors
       array<size_t, s_rotorCnt>Steps;     //steps taken by rotors
       array<size_t, s_rotorCnt>Key;       //choosen keys
       array<size_t, s_rotorCnt>Ring;      //ring set
    };    
    rotors d_rots;
    
    Wiring d_SB, d_ETW;                    //plugboard and entry board
    Wiring d_UKW_A, d_UKW_B, d_UKW_C;      //possible refelectors

    Rotor d_I,  d_II, d_III, d_IV,
          d_V,  d_VI, d_VII, d_VIII;       //choices of rotor wheels
    
    Wiring *d_UKW;                         //pointer to choosen reflector

    vector<string>*d_rflLst;               //list available refelectors (id's)
    vector<string>*d_rotLst;               //list available rotors (id's)
    
    string *d_rflMap;                      //rfl details (id, wiring)
    string *d_rotMap;                      //rot details (id, wiring, notches)
    string *d_version;
    string *d_debug;

    void defRotors();                      //define the rotors
    void defETWUKW();                      //define the reflectors and ETW
    Rotor *getRotor(string const rotorId); //pointer to the rotor with rotorId

    size_t fwdRtEncypher(encStp rPos, size_t idx_inp) const;
    size_t bckRtEncypher(encStp rPoS, size_t idx_inp) const;
    size_t fwdWrEncypher(Wiring const &wr, size_t idx_inp) const;
    size_t bckWrEncypher(Wiring const &wr, size_t idx_inp) const;

    size_t romanToInt(string const &id) const; //convert "I" "II",  to size_t
    string StpToStr(encStp const stp);         //enumeration to string

    bool willStep(encStp rPos) const;           //will the rotor at rPos step?
    bool turnAt(encStp rPos, size_t pos) const; //will the rotor turn now?
    void turnRots();                            //calls rotate()
    void rotate(encStp rPos);                   //rotate a rotor at rPos
    void debug(encStp stp, size_t ch);
};

#endif // ENIGMAIMPL_H
