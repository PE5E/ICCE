#include "enigmaimpl.ih"

EnigmaImpl::EnigmaImpl()
  : d_rflLst(new vector<string>), d_rotLst(new vector<string>),
    d_rflMap(new string{}), d_rotMap(new string{}),
    d_debug(new string{})
    
{
    d_version  = new string{"1.4.1 22-03-2018"};

    defETWUKW();
    defRotors();
}
