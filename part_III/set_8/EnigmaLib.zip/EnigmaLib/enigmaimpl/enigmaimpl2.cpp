#include "enigmaimpl.ih"

EnigmaImpl::~EnigmaImpl()
{
  delete d_rflLst;
  delete d_rotLst;

  delete d_debug;
  delete d_version;
  delete d_rotMap;
  delete d_rflMap;
}
