#include "enigmaimpl.ih"

//the turning is considered in a fixed frame 0 .. wireSze() with 0 matching
//the top; input has to be mapped on the turned rotor position (due to
//steps and key) and output is mapped back on the fixed frame
//all values in the offset calculations have to stay in the range 0 ..wireSze()
//(idx - steps - key) % wireSze() might fail if steps + key > idx
size_t EnigmaImpl::fwdRtEncypher(encStp rPos, size_t idx) const
{ 
   Rotor *rot = d_rots.Rot.at(rPos);
   size_t ring = d_rots.Ring.at(rPos);
   
   idx = rot->rotWr().permute((idx +
                               alphabetSze() - ring +
			       rotView(rPos))
			       % alphabetSze());
   return (idx +
	  ring +
	  alphabetSze() - rotView(rPos))
          % alphabetSze();
}
