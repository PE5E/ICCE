#include "enigmaimpl.ih"

//give the permutation induced by the specific wiring
size_t EnigmaImpl::fwdWrEncypher(Wiring const &wr, size_t idx) const
{
    return wr.permute(idx);
}
