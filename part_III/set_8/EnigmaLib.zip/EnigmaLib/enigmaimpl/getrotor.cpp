#include "enigmaimpl.ih"

//return the rotor with the given string Id
Rotor *EnigmaImpl::getRotor(string const rotorId)
{
  switch(romanToInt(rotorId))
  {
     case 1: return &d_I;
     case 2: return &d_II;
     case 3: return &d_III;
     case 4: return &d_IV;
     case 5: return &d_V;
     case 6: return &d_VI;
     case 7: return &d_VII;
     case 8: return &d_VIII;
     default: throw "Unknown rotor ID in getRotor";
  };
}
