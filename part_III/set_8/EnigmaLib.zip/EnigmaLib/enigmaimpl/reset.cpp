#include "enigmaimpl.ih"

//initialize rotor steps to 0
//this is the starting config
void EnigmaImpl::reset()
{
   for(size_t idx = 0; idx != s_rotorCnt; ++idx)
      d_rots.Steps.at(idx) = 0;
}
