#include "enigmaimpl.ih"

//return the list of available(defined) reflectors
vector<string> *EnigmaImpl::rflLst() const
{
   return d_rflLst;
}
