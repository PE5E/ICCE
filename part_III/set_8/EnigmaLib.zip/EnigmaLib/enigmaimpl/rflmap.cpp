#include "enigmaimpl.ih"

string *EnigmaImpl::rflMap() const
{
    *d_rflMap =  string(d_UKW->wireId() + "\t " + d_UKW->wrMap());
    return d_rflMap;
}
