#include "enigmaimpl.ih"

//convert(historic) rotor Id's to num value
size_t EnigmaImpl::romanToInt(string const &id) const
{
  if(id == "I")    return 1;
  if(id == "II")   return 2;
  if(id == "III")  return 3;
  if(id == "IV")   return 4;
  if(id == "V")    return 5;
  if(id == "VI")   return 6;
  if(id == "VII")  return 7;
  if(id == "VIII") return 8;

  throw "Unknown rotor id in romanToInt";
}
