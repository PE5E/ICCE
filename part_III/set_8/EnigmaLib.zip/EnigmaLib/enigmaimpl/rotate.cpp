#include "enigmaimpl.ih"

//turn the rotor at rPos and increase the steps set by 1
void EnigmaImpl::rotate(encStp rPos)
{
   ++d_rots.Steps.at(rPos) %= alphabetSze();
}
