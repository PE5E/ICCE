#include "enigmaimpl.ih"

//return list of available(defined) rotors
vector<string> *EnigmaImpl::rotLst() const
{
   return d_rotLst;
}
