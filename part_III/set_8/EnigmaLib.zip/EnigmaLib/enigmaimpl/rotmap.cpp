#include "enigmaimpl.ih"

//give layout of the rotor at rPos: its Id, wiring and notch(es)
string *EnigmaImpl::rotMap(size_t rPos) const
{
  *d_rotMap = d_rots.Rot.at(rPos)->rotId() + "\t " +
              d_rots.Rot.at(rPos)->rotsWr() + " " +
              d_rots.Rot.at(rPos)->rotsNt();

  return d_rotMap;

}
