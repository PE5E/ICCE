#include "enigmaimpl.ih"

//return count of rotors
size_t EnigmaImpl::rotorCnt()
{
  return s_rotorCnt;
}
