#include "enigmaimpl.ih"

//return the number that is visible on the enigma window
//called before each encryption step
size_t EnigmaImpl::rotView(size_t rPos) const
{
  return (d_rots.Key.at(rPos) +
          d_rots.Steps.at(rPos)) % alphabetSze();
}
