#include "enigmaimpl.ih"

void EnigmaImpl::setRfl(string const &rflId)
{
   if(rflId == "UKW-A") d_UKW = &d_UKW_A;
   if(rflId == "UKW-B") d_UKW = &d_UKW_B;
   if(rflId == "UKW-C") d_UKW = &d_UKW_C;
}
