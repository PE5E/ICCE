#include "enigmaimpl.ih"

//make the array of installed rotors (plugged into Enigma)
//this contains the reference to the rotor, the rotor Id and
//the key setting and the ring setting for the specific rotor
void EnigmaImpl::setRot(size_t rPos, string const &rotId,
                        size_t key, size_t ring)
{
  d_rots.Rot.at(rPos)   = getRotor(rotId);
  d_rots.Key.at(rPos)   = key;
  d_rots.Ring.at(rPos)  = ring;
}
