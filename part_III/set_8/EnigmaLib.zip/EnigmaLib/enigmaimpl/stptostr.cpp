#include "enigmaimpl.ih"

//to create a string showing specific step of encryption
string EnigmaImpl::StpToStr(encStp const stp)
{
  switch(stp)
  {
    case roR: return "roR";
    case roM: return "roM";
    case roL: return "roL";
    case SB:  return "SB";
    case ETW: return "ETW";
    case UKW: return "UKW";
    default:  throw "Unknown encStp";
  }
}
