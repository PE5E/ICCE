#include "enigmaimpl.ih"

//given the rotor at rPos, will it initiate a turn of its left neighbour?
bool EnigmaImpl::turnAt(encStp rPos, size_t pos) const
{
  return (d_rots.Rot.at(rPos)->turnOver(pos));
}
