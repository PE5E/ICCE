#include "enigmaimpl.ih"

//turn rotors, mandatory sequence to follow Left(2) => Middle(1) => Right(0)
//otherwise rotors will not turn properly as determining notch is at
//right hand side of neighbouring rotor; right rotor will always turn
void EnigmaImpl::turnRots()
{
   if(willStep(encStp::roL)) rotate(encStp::roL);
   if(willStep(encStp::roM)) rotate(encStp::roM);
   rotate(encStp::roR);
}
