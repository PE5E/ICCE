#include "enigmaimpl.h"

string *EnigmaImpl::version() const
{
    return d_version;
}
