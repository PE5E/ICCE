#include "enigmaimpl.ih"

//determines if a rotor will turn next step
//depends on turnover position of right and middle rotor
//the rotor turns if the idx in the rotorview matches the turnAt idx
//notch of left rotor has no impact
//right rotor must always turn
//mechanical double stepping of middle rotor is also covered by the algorithm
// roR = 0, roM = 1, roL = 2
bool EnigmaImpl::willStep(encStp rPos) const
{
  switch(rPos)
  {
    case encStp::roL: return turnAt(encStp::roM, rotView(encStp::roM));
    case encStp::roM: return turnAt(encStp::roR, rotView(encStp::roR)) ||
                             turnAt(encStp::roM, rotView(encStp::roM));
    case encStp::roR: return true;
    default: throw "unknown rotor encountered in willStep()";
  }
}
