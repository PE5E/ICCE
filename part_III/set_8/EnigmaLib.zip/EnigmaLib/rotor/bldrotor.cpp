#include "rotor.ih"

//setup wiring and turnover of a rotor
void Rotor::bldRotor(Wiring const &wr, vector<size_t> const &turnOver)
{
    d_wr = wr;
    d_turnOver = turnOver;
}
