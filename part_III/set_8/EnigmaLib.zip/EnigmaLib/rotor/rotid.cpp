#include "rotor.ih"

//return the Id of a specific rotor
string Rotor::rotId() const
{
    return d_wr.wireId();
}
