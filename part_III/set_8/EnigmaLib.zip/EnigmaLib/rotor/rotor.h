#ifndef ROTOR_H
#define ROTOR_H

#include <cstddef>
#include "../wiring/wiring.h"
#include "../using.ih"

class Wiring;

class Rotor{

public:
    Rotor();
    ~Rotor();

    bool turnOver(size_t pos) const; //will the rotor and its left neighbour turn
    
    string rotId() const;
    string rotsWr() const; //wiring of rotor as a string
    string rotsNt() const; //turnover points of the rotor as string
    Wiring rotWr() const;  //rotors use same Wiring class as stators
    
    void bldRotor(Wiring const &wr, vector<size_t> const &turnOver);

private:
    Wiring d_wr;
    vector<size_t> d_turnOver; //list of rotor turnover points    
};

#endif // ROTOR_H
