#include "rotor.ih"

Rotor::~Rotor()
{
}
