#include "rotor.ih"

//return list of turnover points of the rotor
string Rotor::rotsNt() const
{
    string str{"{"};
    for(auto idx = d_turnOver.begin(); idx != d_turnOver.end(); ++idx)
    {
       str.push_back(*idx +'A');
       str += ",";
    }

    str.at(str.size() - 1) = '}';

    return str;
}
