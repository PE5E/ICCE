#include "rotor.ih"

string Rotor::rotsWr() const
{
    string str{};
    for(size_t idx = 0; idx != Wiring::alphabetSze(); ++idx)
      str.push_back(d_wr.permute(idx) + 'A');

    return str;
}
