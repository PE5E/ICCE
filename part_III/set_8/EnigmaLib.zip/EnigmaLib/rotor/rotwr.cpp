#include "rotor.ih"

Wiring Rotor::rotWr() const
{
  return d_wr;
}
