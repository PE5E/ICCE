#include "rotor.ih"

//return true if pos is a turnover point
bool Rotor::turnOver(size_t pos) const
{
    for(auto idx = d_turnOver.begin(); idx != d_turnOver.end(); ++idx)
      if(*idx == pos) return true;

    return false;
}
