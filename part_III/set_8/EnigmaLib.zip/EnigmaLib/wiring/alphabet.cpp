#include "wiring.ih"

string Wiring::alphabet()
{  
  return s_alphabet;
}
