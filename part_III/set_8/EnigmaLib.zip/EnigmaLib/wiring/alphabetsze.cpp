#include "wiring.ih"

size_t Wiring::alphabetSze()
{    
  return s_alphabetSze;
}
