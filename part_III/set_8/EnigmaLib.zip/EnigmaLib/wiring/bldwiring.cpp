#include "wiring.ih"

//wiring layout can be given either as 0 .. 25 or 'A' .. 'Z'
//the stored wiring is always 0 .. 25 so 'A' .. 'Z' has to be converted
//wr is a string which will be kept in d_wireStr for user query on lay-out
//wr is converted to datatype Wiring
void Wiring::bldWiring(string const &wireId, string const &wr)
{
    d_wireId = wireId;
    d_wiringStr = wr;

    d_wiring.assign(alphabetSze(), 0); //all set to char 0
    for(size_t idx = 0; idx != alphabetSze(); ++idx)
       d_wiring.at(idx) = (wr.at(idx) >= 'A' ? wr.at(idx) - 'A' : wr.at(idx));
}
