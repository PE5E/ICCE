#include "wiring.ih"

//return the connection through the wiring right to left
size_t Wiring::permute(size_t idx) const
{
   return d_wiring.at(idx);
}
