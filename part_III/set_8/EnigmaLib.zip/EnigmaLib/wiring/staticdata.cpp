#include "wiring.ih"

string Wiring::s_alphabet{"ABCDEFGHIJKLMNOPQRSTUVWXYZ"};
size_t Wiring::s_alphabetSze = Wiring::s_alphabet.size();
