#include "wiring.ih"

string Wiring::wireId() const
{
    return d_wireId;
}
