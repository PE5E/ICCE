#ifndef WIRING_H
#define WIRING_H

#include <cstddef>
#include <string>
#include "../using.ih"

class Wiring{
 
public:
    Wiring();
    Wiring(string const &wireId, string const &wr);
    ~Wiring();

    static string alphabet();         //used or available alphabet
    static size_t alphabetSze();      //#chars in the alphabet
    string wireId() const;            //id or name
    string wrMap() const;             //permutation map
    size_t permute(size_t idx) const; //output of idx permutation

    void bldWiring(string const &wireId, string const &wr);

private:
    static string s_alphabet;
    static size_t s_alphabetSze;
    string d_wireId;
    vector<size_t> d_wiring;
    string d_wiringStr;
};

#endif // WIRING_H
