#include "wiring.ih"

Wiring::Wiring()
{
}
