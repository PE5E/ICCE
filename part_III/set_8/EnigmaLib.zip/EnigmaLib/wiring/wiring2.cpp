#include "wiring.ih"

Wiring::Wiring(string const &wireId, string const &wr)
{
    bldWiring(wireId, wr);
}
