#include "wiring.ih"

string Wiring::wrMap() const
{
   return d_wiringStr;
}
