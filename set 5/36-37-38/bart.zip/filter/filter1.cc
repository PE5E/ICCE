#include "filter.ih"

Filter::Filter()
    :
        d_String()
{
    // thats all folks
}
