#include "filter.ih"

Filter::Filter(std::istream &is)
    :
        d_String(is)
{
    // thats all folks
}
