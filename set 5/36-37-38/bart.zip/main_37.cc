#include "filter/filter.h"
#include <iostream>

int main()
{
    Filter fil(std::cin);
    fil.display();
}
