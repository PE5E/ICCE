#include "strings.ih"

Strings::Strings()          // default constructor returns null pointer
{
}
