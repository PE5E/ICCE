#ifndef __STRUCTS_H
#define __STRUCTS_H

#include <string>               // <string>, size_t

struct Rel {
    std::string *data;
    size_t size;
};

#endif

