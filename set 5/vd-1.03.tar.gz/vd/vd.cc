#include <stdio.h>
#include <string.h>

typedef enum
{
    NONE, ARRAY, FUNCTION, POINTER
}
l_type;

char postfix[120], prefix[120];

char const *id = "VD by Frans H.R. v.d. Zande && Frank B. Brokken";

int unit_flag = 1;

l_type last_type = NONE;

void info(char *progname)
{
    fprintf(stderr, "Use %s varname [a|f|p]+ type\n"
           "    to create variables of 'type', being combinations of\n"
           "    a-arrays of; p-pointers to; f-functions returning.\n"
	   "\n"
	   ,
           progname);
    return;
}

void unit()
{
    if (!unit_flag)
    {
        unit_flag++;

        strcat(postfix,")");
        strcat(prefix, "(");
    }
}

char *strrev(char *s)
{
    char
	c,
	*from,
	*to;

    for (from = s, to = s + strlen(s) - 1; from < to; from++, to--)
    {
	c = *from;
	*from = *to;
	*to = c;
    }
    return (s);
}

int main(int argc, char **argv)
{
    fprintf(stderr, "\nVD L-V1.03 (c) ICCE 1988-1995, GPL 1995-2011\n");

    if (argc < 4)
    {
        info(argv[0]);
        return (1);
    }

    while (*argv[2])
    {
        switch (*argv[2]++)
        {
            case 'a':
                if (last_type == FUNCTION)
                {
                    printf("Functions don't return arrays.\n");
                    return(1);
                }
                unit();
                strcat(postfix,"[]");
                last_type = ARRAY;
                break;
            case 'f':
                if (last_type == FUNCTION)
                {
                    printf("Functions don't return functions.\n");
                    return (1);
                }
                if (last_type == ARRAY)
                {
                    printf("Arrays don't return functions.\n");
                    return (1);
                }
                unit();
                strcat(postfix,"()");
                last_type = FUNCTION;
                break;
            case 'p':
                unit_flag = 0;
                strcat(prefix, "*");
                last_type = POINTER;
                break;
            default:
                info(argv[0]);
                return (1);
        }
    }
    printf("\n%s %s%s%s;\n"
	"\n"
	, argv[3], strrev(prefix), argv[1], postfix);
    return (0);
}

