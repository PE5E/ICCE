#include "processaccounter.ih"

ProcessAccounter::~ProcessAccounter()
{
    delete d_process;
}
